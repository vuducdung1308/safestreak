// finalLeaderboard.mjs — reproducible final leaderboard for SafeStreak.
//
// Reads Revealed / StreakUpdated events from the SafeStreak contract via a
// plain JSON-RPC endpoint (no dependencies, plain fetch). Filters reveals
// with block timestamp <= 2026-12-09T08:00:00Z (final snapshot), ranks by:
//   1. bestCorrectStreak desc
//   2. totalCorrect desc
//   3. earliest time bestCorrectStreak was achieved
//   4. tx index, then log index (of the reveal that achieved the best)
// Outputs Top 3 + the full table as JSON.
//
// Reproducibility: the same result can be rebuilt from BscScan by exporting
// the contract's Revealed events up to the snapshot block and applying the
// same ranking. Never publishes balances — only handle (.ai name if
// available via handleOf, else address), bestCorrectStreak, totalCorrect,
// bestAchievedAt.
//
// Env (required):
//   RPC_URL             BNB Chain JSON-RPC endpoint
//   SAFESTREAK_ADDRESS  deployed SafeStreak contract address
// Optional:
//   FROM_BLOCK          first block to scan (default 0)
//   SNAPSHOT_BLOCK      snapshot block number (default: found by binary
//                       search on block timestamps for 2026-12-09T08:00:00Z)
//   OUT                 output file path (default: stdout only)
//   AGENT_ID_ADDRESS    not used here; kept for symmetry with countAgentIds
//
// Usage: node finalLeaderboard.mjs [--help] [--out leaderboard.json]
//
// The contract is NOT deployed yet — this script fails with a clear message
// until RPC_URL and SAFESTREAK_ADDRESS are set.

const SNAPSHOT_ISO = '2026-12-09T08:00:00Z'
const SNAPSHOT_TS = Math.floor(Date.parse(SNAPSHOT_ISO) / 1000)

// Event topic0 hashes (keccak256 of the canonical signature), computed with
// ethers v6 — see frontend/src/abi.json for the signatures.
const REVEALED_TOPIC = '0xf8dce13f7349ef4aeb1e19956bcb1df0f72daec79d7b3123dc255dae2b5b10ae'
const HANDLEOF_SELECTOR = '0xc50a1514' // handleOf(address)

function usage() {
  console.log(`Usage: node finalLeaderboard.mjs [--help] [--out <file>]

Env (required): RPC_URL, SAFESTREAK_ADDRESS
Env (optional): FROM_BLOCK (default 0), SNAPSHOT_BLOCK, OUT
Snapshot: ${SNAPSHOT_ISO} — reveals after this time are excluded.`)
}

const args = process.argv.slice(2)
if (args.includes('--help') || args.includes('-h')) {
  usage()
  process.exit(0)
}
const outIdx = args.indexOf('--out')
const outFile = outIdx >= 0 ? args[outIdx + 1] : process.env.OUT || null
if (outIdx >= 0 && !outFile) {
  console.error('Error: --out requires a file path.')
  process.exit(1)
}

const RPC_URL = process.env.RPC_URL
const ADDRESS = process.env.SAFESTREAK_ADDRESS
if (!RPC_URL) {
  console.error('Error: RPC_URL env var is missing.')
  process.exit(1)
}
if (!ADDRESS) {
  console.error('Error: SAFESTREAK_ADDRESS env var is missing — the SafeStreak contract is not deployed yet.')
  process.exit(1)
}
const FROM_BLOCK = Number(process.env.FROM_BLOCK || 0)

async function rpc(method, params) {
  const res = await fetch(RPC_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  })
  const json = await res.json()
  if (json.error) throw new Error(`RPC ${method} failed: ${json.error.message}`)
  return json.result
}

const hexToInt = (h) => Number.parseInt(h, 16)
const toHex = (n) => '0x' + n.toString(16)

async function blockTimestamp(blockNumber) {
  const block = await rpc('eth_getBlockByNumber', [toHex(blockNumber), false])
  return block ? hexToInt(block.timestamp) : null
}

// Binary search: last block with timestamp <= SNAPSHOT_TS.
async function findSnapshotBlock() {
  if (process.env.SNAPSHOT_BLOCK) return Number(process.env.SNAPSHOT_BLOCK)
  const latest = hexToInt(await rpc('eth_blockNumber', []))
  let lo = FROM_BLOCK
  let hi = latest
  while (lo < hi) {
    const mid = Math.floor((lo + hi + 1) / 2)
    const ts = await blockTimestamp(mid)
    if (ts !== null && ts <= SNAPSHOT_TS) lo = mid
    else hi = mid - 1
  }
  return lo
}

async function getLogs(fromBlock, toBlock) {
  const logs = []
  const CHUNK = 5000
  for (let from = fromBlock; from <= toBlock; from += CHUNK) {
    const to = Math.min(from + CHUNK - 1, toBlock)
    const chunk = await rpc('eth_getLogs', [{
      address: ADDRESS,
      fromBlock: toHex(from),
      toBlock: toHex(to),
      topics: [[REVEALED_TOPIC]],
    }])
    logs.push(...chunk)
  }
  return logs
}

function decodeRevealed(log) {
  const user = '0x' + log.topics[1].slice(26)
  const data = log.data.slice(2)
  const word = (i) => BigInt('0x' + data.slice(i * 64, (i + 1) * 64))
  return {
    user: user.toLowerCase(),
    challengeId: hexToInt(log.topics[2]),
    correct: word(0) !== 0n,
    currentCorrectStreak: Number(word(1)),
    bestCorrectStreak: Number(word(2)),
    totalCorrect: Number(word(3)),
    blockNumber: hexToInt(log.blockNumber),
    txIndex: hexToInt(log.transactionIndex),
    logIndex: hexToInt(log.logIndex),
  }
}

async function handleOf(user) {
  try {
    const data = HANDLEOF_SELECTOR + user.slice(2).padStart(64, '0')
    const raw = await rpc('eth_call', [{ to: ADDRESS, data }, 'latest'])
    if (!raw || raw === '0x') return null
    const body = raw.slice(2)
    const offset = Number.parseInt(body.slice(0, 64), 16) * 2
    const len = Number.parseInt(body.slice(offset, offset + 64), 16)
    const str = Buffer.from(body.slice(offset + 64, offset + 64 + len * 2), 'hex').toString('utf8')
    return str || null
  } catch {
    return null
  }
}

const snapshotBlock = await findSnapshotBlock()
const snapshotTs = await blockTimestamp(snapshotBlock)
if (snapshotTs === null || snapshotTs > SNAPSHOT_TS) {
  console.error(`Error: could not find a block at or before ${SNAPSHOT_ISO}.`)
  process.exit(1)
}

const logs = await getLogs(FROM_BLOCK, snapshotBlock)
// Cache block timestamps (one RPC call per distinct block).
const tsCache = new Map()
async function tsOf(blockNumber) {
  if (!tsCache.has(blockNumber)) tsCache.set(blockNumber, await blockTimestamp(blockNumber))
  return tsCache.get(blockNumber)
}

const byUser = new Map()
for (const log of logs) {
  const r = decodeRevealed(log)
  const ts = await tsOf(r.blockNumber)
  if (ts === null || ts > SNAPSHOT_TS) continue
  let u = byUser.get(r.user)
  if (!u) {
    u = { address: r.user, bestCorrectStreak: 0, totalCorrect: 0, bestAchievedAt: null, bestTxIndex: 0, bestLogIndex: 0, events: [] }
    byUser.set(r.user, u)
  }
  u.events.push({ best: r.bestCorrectStreak, ts, txIndex: r.txIndex, logIndex: r.logIndex })
  if (r.bestCorrectStreak > u.bestCorrectStreak) {
    u.bestCorrectStreak = r.bestCorrectStreak
    u.bestAchievedAt = new Date(ts * 1000).toISOString()
    u.bestTxIndex = r.txIndex
    u.bestLogIndex = r.logIndex
  }
  u.totalCorrect = Math.max(u.totalCorrect, r.totalCorrect)
}
// Earliest time the final best streak was achieved.
for (const u of byUser.values()) {
  const hits = u.events.filter((e) => e.best === u.bestCorrectStreak).sort((a, b) => a.ts - b.ts || a.txIndex - b.txIndex || a.logIndex - b.logIndex)
  if (hits.length) {
    u.bestAchievedAt = new Date(hits[0].ts * 1000).toISOString()
    u.bestTxIndex = hits[0].txIndex
    u.bestLogIndex = hits[0].logIndex
  }
  delete u.events
}

const table = [...byUser.values()]
  .sort((a, b) =>
    b.bestCorrectStreak - a.bestCorrectStreak ||
    b.totalCorrect - a.totalCorrect ||
    (a.bestAchievedAt < b.bestAchievedAt ? -1 : a.bestAchievedAt > b.bestAchievedAt ? 1 : 0) ||
    a.bestTxIndex - b.bestTxIndex ||
    a.bestLogIndex - b.bestLogIndex)
  .map((u, i) => ({ ...u }))

for (const row of table) {
  row.handle = (await handleOf(row.address)) || row.address
  delete row.bestTxIndex
  delete row.bestLogIndex
}
const ranked = table.map((r, i) => ({
  rank: i + 1,
  handle: r.handle,
  address: r.address,
  bestCorrectStreak: r.bestCorrectStreak,
  totalCorrect: r.totalCorrect,
  bestAchievedAt: r.bestAchievedAt,
}))

const result = {
  snapshot: SNAPSHOT_ISO,
  snapshotBlock,
  generatedAt: new Date().toISOString(),
  contract: ADDRESS,
  top3: ranked.slice(0, 3),
  table: ranked,
}

const json = JSON.stringify(result, null, 2)
if (outFile) {
  const { writeFileSync } = await import('node:fs')
  writeFileSync(outFile, json + '\n')
  console.log(`Wrote ${ranked.length} ranked users (Top 3 included) to ${outFile}`)
} else {
  console.log(json)
}
